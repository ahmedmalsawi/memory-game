## Module <om_account_bank_statement_import>

#### 15.04.2022
#### Version 15.0.2.1.0
##### IMP
- turkish translation

#### 20.12.2021
#### Version 15.0.2.0.0
##### FIX
- access right error
