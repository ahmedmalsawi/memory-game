## Module <om_account_followup>

#### 15.04.2022
#### Version 15.0.2.0.0
##### IMP
- remove warning

#### 15.04.2022
#### Version 15.0.1.1.0
##### IMP
- turkish translation

#### 03.03.2022
#### Version 15.0.1.0.0
##### ADD
- Initial commit



