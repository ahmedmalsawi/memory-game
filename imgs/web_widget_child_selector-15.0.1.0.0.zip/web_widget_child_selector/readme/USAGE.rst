Use child_selector widget on a field.
If necessary we can use child_selection_field on options in order to define
which field we will show on edition only.
For example, name instead of display_name.
