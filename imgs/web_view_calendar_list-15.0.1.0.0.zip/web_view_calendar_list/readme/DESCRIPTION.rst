This module adds a new view type that can be used to show calendars as lists.
