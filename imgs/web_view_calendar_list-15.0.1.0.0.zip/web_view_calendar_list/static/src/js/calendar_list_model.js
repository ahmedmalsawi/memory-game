odoo.define("web_view_calendar_list.CalendarListModel", function (require) {
    "use strict";
    var CalendarModel = require("web.CalendarModel");
    return CalendarModel.extend({});
});
