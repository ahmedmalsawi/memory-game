odoo.define("web_view_calendar_list.CalendarListController", function (require) {
    "use strict";
    var CalendarController = require("web.CalendarController");
    return CalendarController.extend({});
});
