* App navigation with keyboard.
* Handle long titles on forms in a better way
