Para instalar esté módulo necesita:

#. El módulo l10n_es_ticketbai_api
